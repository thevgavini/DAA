<?php
// Start the session
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['loggedIn']) || $_SESSION['loggedIn'] !== true) {
    // Redirect to the login page
    header("Location: ../login_pages/login.php");
    exit;
}

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the submitted form data
    $newPassword = $_POST['new_password'];
    $confirmPassword=$_POST['confirm_password'];

    if($newPassword != $confirmPassword){
        echo '<script>if(confirm("Passwords do not match!")){window.location.href="reset_pwd.php";}else{window.location.href="reset_pwd.php";}</script>';
    }
    else{
        $username = $_SESSION['username'];
        $db = new PDO('sqlite:../db/db_member.sqlite3');
        $sql = "UPDATE member SET password = :newPassword WHERE username = :username";
        $stmt = $db->prepare($sql);
        $stmt->bindParam(':newPassword', $newPassword);
        $stmt->bindParam(':username', $username);

        if ($stmt->execute()) {
            echo 'Password reset successfully.';
            header("Location: home.php");
        } else {
            echo 'Error resetting password.';
            header("Location: reset_pwd.php");
        }
    } 

    }
    else {
        // Redirect to the password reset page if accessed directly without a POST request
        header("Location: reset_pwd.php");
        exit;
    }
    
?>
