<div class="navbar">
    <ul>
        <li><a href="../stored_xss/book_records.php" <?php if (basename($_SERVER['PHP_SELF']) == 'book_records.php') { echo 'class="active"'; } ?>>StoredXSS</a></li>
        <li><a href="../stored_xss/book_records_fixed.php" <?php if (basename($_SERVER['PHP_SELF']) == 'book_records_fixed.php') { echo 'class="active"'; } ?>>StoredXSS Fixed</a></li>
        <li><a href="../dom_xss/dom_xss.php" <?php if (basename($_SERVER['PHP_SELF']) == 'dom_xss.php') { echo 'class="active"'; } ?>>DOM XSS</a></li>
        <li><a href="../dom_xss/dom_xss_fixed.php" <?php if (basename($_SERVER['PHP_SELF']) == 'dom_xss_fixed.php') { echo 'class="active"'; } ?>>DOM XSS Fixed</a></li>
        <li><a href="../csrf/reset_pwd.php" <?php if (basename($_SERVER['PHP_SELF']) == 'reset_pwd.php') { echo 'class="active"'; } ?>>CSRF</a></li>
        <li><a href="../csrf/reset_pwd_csrf.php" <?php if (basename($_SERVER['PHP_SELF']) == 'reset_pwd_csrf.php') { echo 'class="active"'; } ?>>CSRF Fixed</a></li>
    </ul>
    <span>Welcome, <?php echo $username; ?></span>
    <ul>
        
        <li><a href="../logout.php">Logout</a></li>
    </ul>
</div>

<style>
    /* CSS styles for the navbar */
    .navbar {
        background-color: #333;
        color: #fff;
        padding: 10px;
        display: flex;
        justify-content: space-between;
    }

    .navbar ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
        display: flex;
    }

    .navbar li {
        margin-right: 10px;
    }

    .navbar li a {
        color: #fff;
        text-decoration: none;
    }

    .navbar li a:hover {
        text-decoration: underline;
    }

    .navbar li a.active {
        text-decoration: underline;
    }
</style>
