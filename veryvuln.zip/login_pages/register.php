<!DOCTYPE html>
<?php 
//starting the session
session_start();
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>VeryVuln</title>
    <!-- Bootstrap -->
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            padding: 20px;
        }

        .navbar {
            background-color: #333;
            color: #fff;
            padding: 10px;
        }

        .navbar-brand {
            color: #fff;
        }

        .col-md-6 {
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        .registration-form-heading {
            text-align: center;
            margin-bottom: 20px;
        }

        .registration-form {
            margin-bottom: 20px;
        }

        .registration-form .form-group label {
            margin-bottom: 5px;
        }

        .registration-form .form-control {
            margin-bottom: 10px;
        }

        .registration-form .alert {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="col-md-6">
            <h3 class="registration-form-heading text-primary">veryVuln</h3>
            <hr style="border-top:1px dotted #ccc;">
            <!-- Link for redirecting to Login Page -->
            <p class="text-center"><a href="login.php">Already a member? Log in here...</a></p>
            <div class="registration-form">
                <!-- Registration Form start -->
                <form method="POST" action="save_member.php">
                    <div class="alert alert-info">Registration</div>
                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" name="username" class="form-control" required="required">
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" class="form-control" required="required">
                    </div>
                    <div class="form-group">
                        <label>Firstname</label>
                        <input type="text" name="firstname" class="form-control" required="required">
                    </div>
                    <div class="form-group">
                        <label>Lastname</label>
                        <input type="text" name="lastname" class="form-control" required="required">
                    </div>
                    <?php
                        //checking if the session 'success' is set.
                        if (isset($_SESSION['success'])) {
                    ?>
                        <!-- Display registration success message -->
                        <div class="alert alert-success"><?php echo $_SESSION['success']; ?></div>
                    <?php
                        //Unsetting the 'success' session after displaying the message.
                        unset($_SESSION['success']);
                        }
                    ?>
                    <button class="btn btn-primary btn-block" name="register">
                        <span class="glyphicon glyphicon-save"></span> Register
                    </button>
                </form>
                <!-- Registration Form end -->
            </div>
        </div>
    </div>
</body>
</html>
