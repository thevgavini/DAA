<div class="navbar">
    <ul>
        <li><a href="login.php" <?php if (basename($_SERVER['PHP_SELF']) == 'login.php') { echo 'class="active"'; } ?>>LoginRegular</a></li>
        <!-- <li><a href="login_sqli.php" <?php if (basename($_SERVER['PHP_SELF']) == 'login_sqli.php') { echo 'class="active"'; } ?>>LoginSQLI</a></li> -->
        <!-- <li><a href="login_sqli_fixed.php" <?php if (basename($_SERVER['PHP_SELF']) == 'login_sqli_fixed.php') { echo 'class="active"'; } ?>>LoginSQLI Fixed</a></li> -->
        <li><a href="login_wrn.php" <?php if (basename($_SERVER['PHP_SELF']) == 'login_wrn.php') { echo 'class="active"'; } ?>>LoginWRN</a></li>
        <li><a href="login_wrn_fixed.php" <?php if (basename($_SERVER['PHP_SELF']) == 'login_wrn_fixed.php') { echo 'class="active"'; } ?>>LoginWRN Fixed</a></li>
        <li><a href="login_improper_exceptions.php" <?php if (basename($_SERVER['PHP_SELF']) == 'login_improper_exceptions.php') { echo 'class="active"'; } ?>>LoginImproperExceptions</a></li>
        <li><a href="login_improper_exceptions_fixed.php" <?php if (basename($_SERVER['PHP_SELF']) == 'login_improper_exceptions_fixed.php') { echo 'class="active"'; } ?>>LoginImproperExceptions Fixed</a></li>
    </ul>
</div>

<style>
    /* CSS styles for the navbar */
    .navbar {
        background-color: #333;
        color: #fff;
        padding: 10px;
        display: flex;
        justify-content: space-between;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
    }

    .navbar ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
        display: flex;
    }

    .navbar li {
        margin-right: 10px;
    }

    .navbar li a {
        color: #fff;
        text-decoration: none;
    }

    .navbar li a:hover {
        text-decoration: underline;
    }

    .navbar li a.active {
        text-decoration: underline;
    }
</style>
