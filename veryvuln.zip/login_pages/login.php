<!DOCTYPE html>
<?php 
// Starting the session
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['loggedIn']) || $_SESSION['loggedIn'] !== true) {
    // Redirect to the login page

}
else{
	header("Location: home.php");
}

?>


<html lang="en">
<head>
    <meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1"/>
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.css"/>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            padding: 20px;
        }
        
        .login-container {
            width: 400px;
            padding: 30px;
            background-color: #f7f7f7;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.3);
        }
        
        .login-container h3 {
            margin-top: 0;
            margin-bottom: 20px;
        }
        
        .login-container .alert {
            margin-bottom: 20px;
        }
        
        .login-container form {
            margin-bottom: 0;
        }
    </style>
</head>
<body>
<?php include 'navbar_login.php'; ?>
    <div class="login-container">
        <h3 class="text-primary">veryVuln</h3>
        <hr style="border-top:1px dotted #ccc;"/>
        <!-- Link for redirecting page to Registration page -->
        <a href="register.php">Not a member yet? Register here...</a>
        <br style="clear:both;"/><br />
        <div class="col-md-6">
            <!-- Login Form Starts -->
            <form method="POST" action="../login_queries/login_query.php">    
                <div class="alert alert-info">Login</div>
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" name="username" class="form-control" required="required"/>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control" required="required"/>
                </div>
                <?php
                    // Checking if the session 'error' is set. Error session is the message if the 'Username' and 'Password' are not valid.
                    if (isset($_SESSION['error'])) {
                ?>
                <!-- Display Login Error message -->
                <div class="alert alert-danger"><?php echo $_SESSION['error']?></div>
                <?php
                    // Unsetting the 'error' session after displaying the message. 
                    unset($_SESSION['error']);
                    }
                ?>
                <button class="btn btn-primary btn-block" name="login"><span class="glyphicon glyphicon-log-in"></span> Login</button>
            </form>    
            <!-- Login Form Ends -->
        </div>
    </div>
</body>
</html>
