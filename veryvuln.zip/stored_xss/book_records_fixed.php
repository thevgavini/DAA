<?php
// Start the session
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['loggedIn']) || $_SESSION['loggedIn'] !== true) {
    // Redirect to the login page
    header("Location: ../login_pages/login.php");
    exit;
}

// Get the username of the logged-in user
$username = isset($_SESSION['username']) ? sanitizeInput($_SESSION['username']) : '';

// Function to sanitize user input
function sanitizeInput($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Fixed Book Records</title>
    <style>
        /* CSS styles for the navbar */
        .navbar {
            background-color: #333;
            color: #fff;
            padding: 10px;
            display: flex;
            justify-content: space-between;
        }

        .navbar ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
        }

        .navbar li {
            margin-right: 10px;
        }

        .navbar li a {
            color: #fff;
            text-decoration: none;
        }

        .navbar li a:hover {
            text-decoration: underline;
        }

        /* Rest of the existing CSS styles */
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
        }

        h1 {
            margin-bottom: 20px;
        }

        form {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"] {
            width: 300px;
            padding: 5px;
            font-size: 14px;
        }

        input[type="submit"],
        input[type="reset"] {
            padding: 5px 10px;
            font-size: 14px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            cursor: pointer;
        }

        h2 {
            margin-bottom: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .record:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
<?php include '../navbar.php'; ?>

    <h1>Fixed Book Records Page</h1>
    <p>This page does not lead to StoredXSS. This is achieved using input filtration.</p>
    <form method="POST" action="save_record_fixed.php">
        <label for="book_name">Book Name:</label>
        <input type="text" name="book_name" id="book_name" required>
        <br>
        <label for="author_name">Author Name:</label>
        <input type="text" name="author_name" id="author_name" required>
        <br>
        <input type="submit" value="Save">
        <input type="reset" value="Reset" onclick="window.location.href='reset.php'">
    </form>

    <h2>Stored Records:</h2>
    <table>
        <tr>
            <th>Book</th>
            <th>Author</th>
        </tr>
        <?php
        // Connect to the SQLite database
        $db = new PDO('sqlite:../db/db_member.sqlite3');

        // Prepare and execute the query
        $query = "SELECT * FROM books";
        $stmt = $db->prepare($query);
        $stmt->execute();

        // Fetch all records from the books table
        $records = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Display the records
        foreach ($records as $index => $record) {
            $bookName = sanitizeInput($record['book_name']);
            $authorName = sanitizeInput($record['author_name']);

            // Apply alternate row styling
            $rowClass = ($index % 2 === 0) ? 'record' : 'record even';

            // Display each record as a table row
            echo "<tr class='$rowClass'>";
            echo "<td>$bookName</td>";
            echo "<td>$authorName</td>";
            echo "</tr>";
        }
        ?>
    </table>
</body>
</html>


