<?php
// Start the session
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['loggedIn']) || $_SESSION['loggedIn'] !== true) {
    // Redirect to the login page
    header("Location: ../login_pages/login.php");
    exit;
}
?>


<?php
// Connect to the SQLite database
$db = new PDO('sqlite:../db/db_member.sqlite3');


// Delete all records from the books table
$queryDelete = "DELETE FROM books";
$db->exec($queryDelete);

// Copy records from books_duplicate to books table
$queryCopy = "INSERT INTO books SELECT * FROM books_duplicate";
$db->exec($queryCopy);

// Redirect back to the book records page
header('Location: book_records.php');
exit();
?>