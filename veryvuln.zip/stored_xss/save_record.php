<?php
// Start the session
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['loggedIn']) || $_SESSION['loggedIn'] !== true) {
    // Redirect to the login page
    header("Location: ../login_pages/login.php");
    exit;
}
?>

<?php
// Connect to the SQLite database
$db = new PDO('sqlite:../db/db_member.sqlite3');

// Retrieve the submitted form data
$bookName = $_POST['book_name'];
$authorName = $_POST['author_name'];

// Perform basic input validation
if (empty($bookName) || empty($authorName)) {
    die('Please fill in all fields');
}

// Prepare the SQL statement to insert the record into the database
$sql = "INSERT INTO books (book_name, author_name) VALUES (:bookName, :authorName)";
$stmt = $db->prepare($sql);
$stmt->bindParam(':bookName', $bookName);
$stmt->bindParam(':authorName', $authorName);

// Execute the SQL statement
if ($stmt->execute()) {
    echo 'Record saved successfully.';
} else {
    echo 'Error saving record.';
}
header('location:book_records.php');
?>
