<?php
// Starting the session
session_start();
// Including the database connection
require_once '../conn.php';

function GetPwdFromDb($username, $conn) {
    // Select Query to retrieve the password from the database based on the given username
    $query = "SELECT `password` FROM `member` WHERE `username` = :username";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':username', $username);
    $stmt->execute();
    $row = $stmt->fetch();

    if ($row) {
        return $row['password'];
    } else {
        return null;
    }
}

function Login($username, $password, $conn) {
    // The boolean variable loggedIn is initialized to true
    $loggedIn = true;
    $realPwd = GetPwdFromDb($username, $conn);

    try {
        if ($realPwd !== $password) {
            throw new Exception("User not found");
            $loggedIn = false;
        }
    } catch (Exception $e) {
        // When an exception is raised, the control shifts to this catch block.
        // As this catch block is empty, the loggedIn boolean stays true, and the attacker is logged in.
        
    }


    return $loggedIn;
}

if (isset($_POST['login'])) {
    // Setting variables
    $username = $_POST['username'];
    $password = $_POST['password'];

    $loggedIn = Login($username, $password, $conn); // Assuming $conn is the database connection variable

    if ($loggedIn) {
        // Set the 'loggedIn' flag in the session
        $_SESSION['loggedIn'] = true;

        // Set the 'username' in the session
        $_SESSION['username'] = $username;

        header('location:../home.php');
    } else {
        $_SESSION['error'] = "Invalid username or password";
        header('location:../login.php');
    }
}
?>
