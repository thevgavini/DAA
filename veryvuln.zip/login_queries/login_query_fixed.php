<?php
require_once '../conn.php';

function generateSessionID() {
    $bytes = random_bytes(16);
    $sessionID = bin2hex($bytes);
    return $sessionID;
}



if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = "SELECT COUNT(*) as count FROM `member` WHERE `username` = :username AND `password` = :password";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $password);
    $stmt->execute();
    $row = $stmt->fetch();

    $count = $row['count'];
    if ($count > 0) {

        $sessionID = generateSessionID();
        session_id($sessionID);
        
        session_start();

        $_SESSION['loggedIn'] = true;
        $_SESSION['username'] = $username;

        header('location:../home.php');
        exit();
    } else {
        $_SESSION['error'] = "Invalid username or password";
        header('location:../login.php');
        exit();
    }
}
?>



