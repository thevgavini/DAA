<?php
// Start the session
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['loggedIn']) || $_SESSION['loggedIn'] !== true) {
    // Redirect to the login page
    header("Location: /login_pages/login.php");
    exit;
}
else{
	header("Location: /stored_xss/book_records.php");
}
?>
