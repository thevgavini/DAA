<?php
	$dbFilePath = __DIR__ . '/db/db_member.sqlite3';

	// check if the database file exists and create a new one if not
	if (!is_file($dbFilePath)) {
		file_put_contents($dbFilePath, null);
	}

	// connecting to the database
	$conn = new PDO('sqlite:' . $dbFilePath);
	// setting connection attributes
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

	// Query for creating the member table if it doesn't exist yet
	$query = "CREATE TABLE IF NOT EXISTS member (
		mem_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
		username TEXT,
		password TEXT,
		firstname TEXT,
		lastname TEXT
	)";
	$query = "CREATE TABLE IF NOT EXISTS books (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		book_name TEXT,
		author_name TEXT
	)";

	// Executing the query
	$conn->exec($query);
?>
