
 <?php
// Starting the session
 session_start();
 header("Location: /login_pages/login.php");
 ?>