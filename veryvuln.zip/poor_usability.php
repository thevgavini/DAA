<!DOCTYPE html>
<html>
<head>
    <title>Add Comment</title>
    <style>
        /* Styles for the popup window */
        .popup {
            display: none;
            position: fixed;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            width: 300px;
            padding: 20px;
            background-color: #f2f2f2;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .popup input[type="text"],
        .popup textarea {
            width: 100%;
            padding: 5px;
            margin-bottom: 10px;
        }
        .popup button {
            background-color: #4CAF50;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
        }
    </style>
    <script>
        function openPopup() {
            var popup = document.getElementById("commentPopup");
            popup.style.display = "block";
        }

        function closePopup() {
            var popup = document.getElementById("commentPopup");
            popup.style.display = "none";
        }
    </script>
</head>
<body>
    <h1>Welcome to the Webpage!</h1>

    <!-- Add Comment button -->
    <button onclick="openPopup()">Add Comment</button>

    <!-- Popup window -->
    <div id="commentPopup" class="popup">
        <h2></h2>
        <form action="" method="post">
            <label for="username"></label>
            <input type="text" id="username" name="username" placeholder="username" required>

            <label for="comment"> </label>
            <input type="text" id="comment" name="comment" required></textarea>

            <button type="submit" name="submit">Go</button>
        </form>
    </div>

    <?php
    // Check if the form is submitted
    if (isset($_POST['submit'])) {
        $username = $_POST['username'];
        $comment = $_POST['comment'];

        // Display the entered data in the "Comments section"
        echo '<h2>Comments section</h2>';
        echo '<p>Username: ' . $username . '</p>';
        echo '<p>Comment: ' . $comment . '</p>';
    }
    ?>
</body>
</html>
