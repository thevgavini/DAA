<?php
// Start the session
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['loggedIn']) || $_SESSION['loggedIn'] !== true) {
    // Redirect to the login page
    header("Location: ../login_pages/login.php");
    exit;
}

// Get the username of the logged-in user
$username = isset($_SESSION['username']) ? $_SESSION['username'] : '';
?>

<!DOCTYPE html>
<html>
<head>
    <title>DOM XSS Fixed - Demo </title>
    <style>
        /* CSS styles for the navbar */
        .navbar {
            background-color: #333;
            color: #fff;
            padding: 10px;
            display: flex;
            justify-content: space-between;
        }

        .navbar ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
        }

        .navbar li {
            margin-right: 10px;
        }

        .navbar li a {
            color: #fff;
            text-decoration: none;
        }

        .navbar li a:hover {
            text-decoration: underline;
        }

        /* Existing CSS styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }

        h1 {
            text-align: center;
        }

        #header {
            text-align: center;
            margin-bottom: 20px;
        }

        .tabs {
            display: flex;
            justify-content: center;
        }

        .tab {
            padding: 10px 20px;
            background-color: #f0f0f0;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .tab.active {
            background-color: #ccc;
        }

        #tabContent {
            margin-top: 20px;
            text-align: center;
        }

        .image-box {
            width: 400px;
            height: 300px;
            border: 1px solid #ccc;
            margin: 0 auto;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .image-box img {
            max-width: 100%;
            max-height: 100%;
        }
    </style>
</head>
<body>
<?php include '../navbar.php'; ?>

    <h1>DOM XSS Fixed</h1>

    <script>
    function chooseTab(num) {
        // Dynamically load the appropriate image.
        var sanitizedNum = sanitizeInput(num);
        var html = "<div class='image-box'>";
        html += "<img src='/image" + sanitizedNum + ".jpg' onerror='' />";
        html += "</div>";
        document.getElementById("tabContent").innerHTML = html;

        window.location.hash = sanitizedNum;

        // Select the current tab
        var tabs = document.getElementsByClassName("tab");
        for (var i = 0; i < tabs.length; i++) {
            if (tabs[i].id == "tab" + sanitizedNum) {
                tabs[i].classList.add("active");
            } else {
                tabs[i].classList.remove("active");
            }
        }

        // Tell parent we've changed the tab
        top.postMessage(self.location.toString(), "*");
    }

    window.onload = function() {
        chooseTab(unescape(self.location.hash.substr(1)) || "1");
    };

    function sanitizeInput(input) {
        // Replace special characters with HTML entities
        var sanitizedInput = input.replace(/&/g, '&amp;')
                                 .replace(/</g, '&lt;')
                                 .replace(/>/g, '&gt;')
                                 .replace(/"/g, '&quot;')
                                 .replace(/'/g, '&#x27;')
                                 .replace(/\//g, '&#x2F;');
        return sanitizedInput;
    }
</script>


    <div id="header">
        <span>We like animals!</span>
    </div>

    <div class="tabs">
        <button class="tab active" id="tab1" onclick="chooseTab('1')">Image 1</button>
        <button class="tab" id="tab2" onclick="chooseTab('2')">Image 2</button>
        <button class="tab" id="tab3" onclick="chooseTab('3')">Image 3</button>
        <button class="tab" id="tab3" onclick="chooseTab('4')">Image 4</button>
    </div>

    <div id="tabContent">&nbsp;</div>
</body>
</html>
